get_idf
idf.py set-target [esp32c3]
idf.py build
